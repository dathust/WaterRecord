/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.datpt.waterrecord.DaoItf;

import com.datpt.waterrecord.model.IndicationModel;

/**
 *
 * @author DatPT
 */
public interface IndicationInterface {
    public boolean InsertIndication(IndicationModel indicationModel);
    public boolean UpdateIndication (IndicationModel indicationModel);
    public boolean DeleteIndication(int maSoGhi);
    
}
